import { Body, Injectable } from '@nestjs/common';
import amqp = require("amqplib/callback_api");

@Injectable()
export class AppService {

  public sendMessage(body: any){
    const queueName = `${body.userIdSend}${body.userIdReceive}`;
    
    amqp.connect('amqp://localhost', function(error0, connection){
      if(error0){
        throw error0
      }
      connection.createChannel(function(error1, channel){
        if(!error1){
          throw error1
        }
        channel.sendToQueue(queueName, Buffer.from(body.message))
      })

      return{
        messagem: 'message sended with success'
      }
    })
  }

  public getMessage(userId){
    let response = []
    let othersUsersId = [
      1,2,4
    ]

    const possibleQueues = othersUsersId.map(e => `${e}${userId}`)

    for(let i = 0; i < possibleQueues.length; i++){
      const queueName = possibleQueues[i];
      console.log(queueName)

      amqp.connect('amqp://localhost', function(error0, connection) {
        if (error0) {
          throw error0;
        }
        connection.createChannel(function(error1, channel) {
          if (error1) {
            throw error1;
          }

          channel.assertQueue(queueName, {
            durable: false
          });

         // console.log(" [*] Waiting for messages in %s. To exit press CTRL+C", queue);
          channel.consume(queueName, function(msg) {
            response.push({
              message: msg.content.toString()
            })
             // console.log(" [x] Received %s", msg.content.toString());
          }, {
              noAck: true
          });
        });
      });
    }

    return response

  }
}
