import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { AppService } from './app.service';

@Controller('message')
export class AppController {
  public constructor(private readonly appService: AppService) {}

  @Post()
  public sendMessage(@Body() body: object){
    // autorização
    return this.appService.sendMessage(body)
  }

  @Get()
  public getMessage(@Query('userId')userId: number){
    return this.appService.getMessage(userId)

    setTimeout(function)
  }

  
}
